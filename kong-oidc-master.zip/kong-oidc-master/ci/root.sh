#!/bin/bash
set -e

apt-get update
apt-get install -y curl unzip libssl-dev python python-pip git

